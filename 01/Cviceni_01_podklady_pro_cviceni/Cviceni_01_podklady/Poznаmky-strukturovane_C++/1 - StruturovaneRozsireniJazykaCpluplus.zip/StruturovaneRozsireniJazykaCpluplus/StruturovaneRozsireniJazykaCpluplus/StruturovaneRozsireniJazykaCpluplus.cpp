﻿// StruturovaneRozsireniJazykaCpluplus.cpp : Tento soubor obsahuje funkci main. Provádění programu se tam zahajuje a ukončuje.
//

#include <iostream>
using namespace std; // std::
#include "MyMath.h"

void tisk(char z)
{
	printf("%c%c%c", '\'', z, '\''); // cout <<
}

void tisk(char z, char sep)
{
	printf("%c%c%c", sep, z, sep);
}

void tisk(char z, int n)
{
	printf("%c:%d", z, n);
}

// -------

// přetížení funkcí

int max(int a, int b)
{
	return a > b ? a : b;
}

int max(int a, int b, int c)
{
	//return ((a > b) ? (a > c ? a : c) : (b > c ? b : c));
	int max;
	if (a > b)
		if (a > c)
			max = b;
		else
			max = c;
	else
		if (b > c)
			max = b;
		else
			max = c;
	return max;
}

char max(char a, char b)
{
	return a > b ? a : b;
}

char* max(char* str1, char* str2)
{
	return (strcmp(str1, str2) == 1 ? str1 : str2);
}

  // ----------

double vzdalenost(double x, double y) // 2d
{
	return sqrt(x * x + y * y);
}

double vzdalenost(double x, double y, double z) // 3d
{
	return sqrt(x * x + y * y + z * z);
}

	// --------------
	// parametr s implicitní hodnotou

double spocitej(double a, double b, char op = '+')
{
	double vysledek;
	switch (op)
	{
	case '+':
		vysledek = a + b;
		break;

	case '-':
		vysledek = a - b;
		break;

	case '*':
		vysledek = a * b;
		break;

	case '/':
		vysledek = a / b;
		break;

	default:
		printf("Neplatny symbol operace.");
		break;
	}

	return vysledek;

}

int main()
{
	double cislo1 = 2.54, cislo2 = 5.25, vysledek1, vysledek2;
	vysledek1 = spocitej(cislo1, cislo2);
	vysledek2 = spocitej(cislo1, cislo2, '*');



	char znak = 'd';
	tisk('a');
	tisk(znak);
	tisk(znak, '-');
	tisk('a', 5);

	int c1, c2;
	int max2cisla;

	c1 = 4; c2 = 5;
	max2cisla = max(c1, c2);

	int c3;
	int max3cisla;
	c3 = 8;
	max3cisla = max(c1, c2, c3);

	char jmeno1[] = "Jan";
	char jmeno2[] = "Adam";
	char* jmenoMax = max(jmeno1, jmeno2);
	cout << jmenoMax << endl;
	
	MyMath myMath;

	jmenoMax = myMath.max(jmeno1, jmeno2);

	



}

// Spuštění programu: Ctrl+F5 nebo nabídka Ladit > Spustit bez ladění
// Ladění programu: F5 nebo nabídka Ladit > Spustit ladění

// Tipy pro zahájení práce:
//   1. K přidání nebo správě souborů použijte okno Průzkumník řešení.
//   2. Pro připojení ke správě zdrojového kódu použijte okno Team Explorer.
//   3. K zobrazení výstupu sestavení a dalších zpráv použijte okno Výstup.
//   4. K zobrazení chyb použijte okno Seznam chyb.
//   5. Pokud chcete vytvořit nové soubory kódu, přejděte na Projekt > Přidat novou položku. Pokud chcete přidat do projektu existující soubory kódu, přejděte na Projekt > Přidat existující položku.
//   6. Pokud budete chtít v budoucnu znovu otevřít tento projekt, přejděte na Soubor > Otevřít > Projekt a vyberte příslušný soubor .sln.
