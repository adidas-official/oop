#pragma once
#include <string.h>

// p�et�en� metod

class MyMath
{
public:
	int max(int a, int b)
	{
		return a > b ? a : b;
	}

	int max(int a, int b, int c)
	{
		//return ((a > b) ? (a > c ? a : c) : (b > c ? b : c));
		int max;
		if (a > b)
			if (a > c)
				max = b;
			else
				max = c;
		else
			if (b > c)
				max = b;
			else
				max = c;
		return max;
	}

	char max(char a, char b)
	{
		return a > b ? a : b;
	}

	char* max(char* str1, char* str2)
	{
		return (strcmp(str1, str2) == 1 ? str1 : str2);
	}

	// ---

	double vzdalenost(double x, double y) // 2d
	{
		return sqrt(x * x + y * y);
	}

	double vzdalenost(double x, double y, double z) // 3d
	{
		return sqrt(x * x + y * y + z * z);
	}

};
